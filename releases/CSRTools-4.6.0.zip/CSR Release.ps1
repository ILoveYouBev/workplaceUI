﻿[CmdletBinding()]
param(
    [ValidateSet('Publish','Install','Prepare','Verify','Check')][string]$Mode,
    [string]$InstallRoot = $PSScriptRoot,
    [string]$RepositoryPath,
    [string]$NextVersion,
    [string]$NotesPath,
    [string]$ManifestPath,
    [string]$PackagePath,
    [int]$WaitPid = 0,
    [string]$AutoHotkeyPath,
    [string]$CompilerPath,
    [string]$BasePath,
    [string]$ResultPath
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (!$InstallRoot) { $InstallRoot = Split-Path -Parent $MyInvocation.MyCommand.Path }
$script:workspaceRoot = [IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')
if (!$CompilerPath) { $CompilerPath = Join-Path $script:workspaceRoot 'Tools\Ahk2Exe.exe' }
if (!$BasePath) { $BasePath = Join-Path $script:workspaceRoot 'Tools\AutoHotkeySC.bin' }
$sourceFiles = @('CSR TOOL 4.3.AHK','CSR UI.ahk','CSR Access.ahk','CSR Updates.ahk')
$requiredFiles = @('CSR Tools.exe','CSR Release.ps1','NSNLIST.txt','CSR Tools - User Guide.txt')
function Get-CSRFileSHA256([string]$LiteralPath) {
    $stream = [IO.File]::OpenRead($LiteralPath)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try {
        return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-','')
    } finally {
        $algorithm.Dispose()
        $stream.Dispose()
    }
}
function Initialize-CSRZipRuntime {
    # Load the .NET ZIP runtime without depending on the PowerShell Archive module.
    [Reflection.Assembly]::Load('System.IO.Compression.FileSystem, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') | Out-Null
}
function Resolve-SafeChild([string]$Parent,[string]$Relative) {
    if ([IO.Path]::IsPathRooted($Relative) -or $Relative -match '(^|[\\/])\.\.([\\/]|$)|:') { throw 'Unsafe update path.' }
    $target = [IO.Path]::GetFullPath((Join-Path $Parent $Relative))
    if (!$target.StartsWith($Parent.TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Update path escaped its directory.' }
    return $target
}
function Invoke-CheckedGit([string[]]$GitArguments) {
    $safeDirectory = [IO.Path]::GetFullPath($RepositoryPath).Replace("\","/")
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        $output = & git -c ("safe.directory=" + $safeDirectory) -C $RepositoryPath @GitArguments 2>&1
        $gitExit = $LASTEXITCODE
    } finally { $ErrorActionPreference = $previousPreference }
    if ($gitExit -ne 0) { throw ('Git failed: ' + ($output -join [Environment]::NewLine)) }
    return ($output -join "`n")
}
function Resolve-PublisherRepository([string]$Selected,[string]$SourceRoot) {
    $candidates = [Collections.Generic.List[string]]::new()
    if ($Selected) {
        $candidates.Add($Selected)
        $candidates.Add((Join-Path $Selected 'Update Github'))
        $candidates.Add((Join-Path $Selected '_Archive_2026-10-07\Update Github'))
    }
    $candidates.Add((Join-Path $SourceRoot 'Update Github'))
    $candidates.Add((Join-Path $SourceRoot '_Archive_2026-10-07\Update Github'))
    $sourceCanonical = [IO.Path]::GetFullPath($SourceRoot).TrimEnd('\')
    foreach ($candidate in $candidates) {
        $canonical = [IO.Path]::GetFullPath($candidate).TrimEnd('\')
        # Never publish from the live source workspace. Use its separate release checkout.
        if ($canonical -eq $sourceCanonical) { continue }
        if (!(Test-Path -LiteralPath (Join-Path $canonical '.git'))) { continue }
        $previousPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            $origin = & git -c ('safe.directory=' + $canonical.Replace('\','/')) -C $canonical remote get-url origin 2>&1
            $originExit = $LASTEXITCODE
        } finally { $ErrorActionPreference = $previousPreference }
        if ($originExit -eq 0 -and ($origin -join "`n").Trim() -match '^(https://github\.com/ILoveYouBev/workplaceUI(?:\.git)?|git@github\.com:ILoveYouBev/workplaceUI(?:\.git)?)$') { return $canonical }
    }
    throw 'No Git checkout was found. In Admin > Publisher setup, choose the folder containing .git for ILoveYouBev/workplaceUI.'
}
function Write-Result([string]$State,[string]$Message) {
    if ($ResultPath) {
        $messageValue = $Message.Replace("`r",' ').Replace("`n",' ')
        [IO.File]::WriteAllText($ResultPath,"[Result]`r`nState=$State`r`nMessage=$messageValue`r`n",[Text.UTF8Encoding]::new($false))
    }
}
try {
    if ($Mode -in @('Publish','Prepare','Check')) {
        if ($NextVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'Release version must use major.minor.patch.' }
        $mainPath = Join-Path $script:workspaceRoot 'CSR TOOL 4.3.AHK'
        $main = [IO.File]::ReadAllText($mainPath)
        $match = [regex]::Match($main,'(?m)^global version := "(\d+\.\d+\.\d+)"')
        if (!$match.Success) { throw 'The local script version could not be read.' }
        $current = [version]$match.Groups[1].Value
        if ([version]$NextVersion -lt $current -or ($Mode -eq 'Publish' -and [version]$NextVersion -eq $current)) { throw 'The next published version must be newer than the installed version.' }
        $notes = if ($NotesPath) { [IO.File]::ReadAllText($NotesPath).Trim() } else { '' }
        if ($notes.Length -lt 5 -or $notes.Length -gt 4000) { throw 'Enter release notes of 5-4000 characters.' }
        if ($Mode -in @('Publish','Check')) {
            $RepositoryPath = Resolve-PublisherRepository $RepositoryPath $script:workspaceRoot
            if ((Invoke-CheckedGit -GitArguments @('status','--porcelain')).Trim()) { throw 'The publishing checkout has uncommitted changes. Resolve them before publishing.' }
            if ((Invoke-CheckedGit -GitArguments @('branch','--show-current')).Trim() -ne 'main') { throw 'The publishing checkout must be on main.' }
            $remote = (Invoke-CheckedGit -GitArguments @('remote','get-url','origin')).Trim()
            if ($remote -notmatch '^(https://github\.com/ILoveYouBev/workplaceUI(?:\.git)?|git@github\.com:ILoveYouBev/workplaceUI(?:\.git)?)$') { throw 'The publishing checkout has an unexpected origin.' }
            if ($Mode -eq 'Publish') {
                Invoke-CheckedGit -GitArguments @('fetch','origin','main') | Out-Null
                Invoke-CheckedGit -GitArguments @('merge','--ff-only','origin/main') | Out-Null
            }
            $remoteManifest = Join-Path $RepositoryPath 'release.ini'
            if (Test-Path -LiteralPath $remoteManifest) {
                $remoteText = [IO.File]::ReadAllText($remoteManifest)
                $remoteMatch = [regex]::Match($remoteText,'(?m)^Version=(\d+\.\d+\.\d+)\r?$')
                if (!$remoteMatch.Success -or [version]$NextVersion -le [version]$remoteMatch.Groups[1].Value) { throw 'Another release already uses this version. Update your client before publishing.' }
            }
        }
        if (!(Test-Path -LiteralPath $CompilerPath -PathType Leaf) -or !(Test-Path -LiteralPath $BasePath -PathType Leaf)) { throw 'Configure Ahk2Exe and its AutoHotkey v1 base in Publisher setup.' }
        if ($Mode -eq 'Check') {
            Write-Result 'READY' ('Publisher ready. Git checkout: ' + $RepositoryPath + '. Next version: ' + $NextVersion)
            exit 0
        }
        $buildRoot = Join-Path $script:workspaceRoot ('_Releases\' + $NextVersion + '-' + [guid]::NewGuid().ToString('N'))
        if (Test-Path -LiteralPath $buildRoot) { throw 'This release directory already exists. Review it and choose another version or move it aside before retrying.' }
        $packageRoot = Join-Path $buildRoot 'package'
        $compileRoot = Join-Path $buildRoot 'source'
        New-Item -ItemType Directory -Path $compileRoot -Force | Out-Null
        if (!(Test-Path -LiteralPath $CompilerPath -PathType Leaf) -or !(Test-Path -LiteralPath $BasePath -PathType Leaf)) { throw 'Configure Ahk2Exe and its AutoHotkey v1 base in Publisher setup.' }
        foreach ($relative in $sourceFiles) { Copy-Item -LiteralPath (Resolve-SafeChild $script:workspaceRoot $relative) -Destination (Join-Path $compileRoot $relative) }
        New-Item -ItemType Directory -Path $packageRoot -Force | Out-Null
        foreach ($relative in @('CSR Release.ps1','NSNLIST.txt','CSR Tools - User Guide.txt')) {
            $source = Resolve-SafeChild $script:workspaceRoot $relative
            if (!(Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing release dependency: $relative" }
            Copy-Item -LiteralPath $source -Destination (Join-Path $packageRoot $relative)
        }
        foreach ($folder in @('Image Search','Hotstrings')) {
            $target = Join-Path $packageRoot $folder
            New-Item -ItemType Directory -Path $target -Force | Out-Null
            $pattern = if ($folder -eq 'Image Search') { '*.png' } else { '*.txt' }
            Get-ChildItem -LiteralPath (Join-Path $script:workspaceRoot $folder) -File -Filter $pattern | ForEach-Object {
                if ($_.Name -ne '-checknis.txt') { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $target $_.Name) }
            }
        }
        $packagedMain = Join-Path $compileRoot 'CSR TOOL 4.3.AHK'
                $compiledSource = [regex]::Replace($main,'(?m)^global version := "\d+\.\d+\.\d+"',('global version := "' + $NextVersion + '"'))
        $compiledSource = [regex]::Replace($compiledSource,'(?m)^;@Ahk2Exe-Set(?:Version|ProductVersion) .*$', {param($m) ($m.Value.Split(' ')[0] + ' ' + $NextVersion)})
        [IO.File]::WriteAllText($packagedMain,$compiledSource,[Text.UTF8Encoding]::new($true))
        # Includes resolve against the staging source directory. No personal scripts are shipped.
        $outExe = Join-Path $packageRoot 'CSR Tools.exe'
        $arguments = '/in "' + $packagedMain + '" /out "' + $outExe + '" /base "' + $BasePath + '" /compress 0 /silent verbose'
        $compile = Start-Process -FilePath $CompilerPath -ArgumentList $arguments -WorkingDirectory $compileRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $buildRoot 'compiler.log') -RedirectStandardError (Join-Path $buildRoot 'compiler-errors.log')
        $compileHandle = $compile.Handle
        if (!$compile.WaitForExit(60000)) { throw 'Compilation timed out. Nothing was published.' }
        $compile.Refresh()
        if ($compile.ExitCode -ne 0 -or !(Test-Path -LiteralPath $outExe)) { throw ('Compilation failed. Read ' + (Join-Path $buildRoot 'compiler.log')) }
        $check = Start-Process -FilePath $outExe -ArgumentList '--verify-build' -WindowStyle Hidden -PassThru
        $checkHandle = $check.Handle
        if (!$check.WaitForExit(30000)) { throw 'Compiled application verification timed out.' }
        $check.Refresh()
        if ($check.ExitCode -ne 0 -or !(Test-Path -LiteralPath ($outExe + '.verified'))) { throw 'Compiled application verification failed.' }
        Remove-Item -LiteralPath ($outExe + '.verified')
        $files = @(Get-ChildItem -LiteralPath $packageRoot -Recurse -File | ForEach-Object {
            @{path=$_.FullName.Substring($packageRoot.Length+1).Replace('\','/');sha256=(Get-CSRFileSHA256 -LiteralPath $_.FullName)}
        })
        @{version=$NextVersion;files=$files} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $packageRoot 'package-manifest.json') -Encoding UTF8
        $zipName = 'CSRTools-' + $NextVersion + '.zip'
        $zipPath = Join-Path $buildRoot $zipName
        Initialize-CSRZipRuntime
        [IO.Compression.ZipFile]::CreateFromDirectory($packageRoot, $zipPath, [IO.Compression.CompressionLevel]::Optimal, $false)
        $hash = (Get-CSRFileSHA256 -LiteralPath $zipPath)
        $manifest = "[Release]`r`nVersion=$NextVersion`r`nMinimumVersion=$NextVersion`r`nPackage=https://raw.githubusercontent.com/ILoveYouBev/workplaceUI/main/releases/$zipName`r`nSHA256=$hash`r`n"
        [IO.File]::WriteAllText((Join-Path $buildRoot 'release.ini'),$manifest,[Text.UTF8Encoding]::new($false))
        [IO.File]::WriteAllText((Join-Path $buildRoot 'release-notes.txt'),$notes,[Text.UTF8Encoding]::new($false))
        $distribution = Join-Path $script:workspaceRoot 'Distribution'
        New-Item -ItemType Directory -Path $distribution -Force | Out-Null
        Copy-Item -LiteralPath $zipPath -Destination (Join-Path $distribution $zipName) -Force
        if ($Mode -eq 'Prepare') {
            Write-Result 'PREPARED' "Prepared $NextVersion. Nothing was uploaded or changed in the running installation."
        } else {
            New-Item -ItemType Directory -Path (Join-Path $RepositoryPath 'releases') -Force | Out-Null
            Copy-Item -LiteralPath $zipPath -Destination (Join-Path $RepositoryPath ('releases\' + $zipName))
            Copy-Item -LiteralPath (Join-Path $buildRoot 'release.ini') -Destination $remoteManifest
            Copy-Item -LiteralPath (Join-Path $buildRoot 'release-notes.txt') -Destination (Join-Path $RepositoryPath 'release-notes.txt')
            [IO.File]::WriteAllText((Join-Path $RepositoryPath 'version.txt'),$NextVersion,[Text.UTF8Encoding]::new($false))
            Invoke-CheckedGit -GitArguments @('add','--','release.ini','release-notes.txt','version.txt',('releases/' + $zipName)) | Out-Null
            Invoke-CheckedGit -GitArguments @('commit','-m',('Required CSR Tools update ' + $NextVersion)) | Out-Null
            Invoke-CheckedGit -GitArguments @('push','origin','main') | Out-Null
            [IO.File]::WriteAllText($mainPath,[IO.File]::ReadAllText($packagedMain),[Text.UTF8Encoding]::new($true))

            Write-Result 'PUBLISHED' "Published $NextVersion. Upgraded clients check within five minutes or at their next sign-in."
        }
    } elseif ($Mode -in @('Install','Verify')) {
        $settings = @{}
        foreach ($line in [IO.File]::ReadAllLines($ManifestPath)) {
            if ($line -match '^([^=]+)=(.*)$') { $settings[$matches[1]] = $matches[2] }
        }
        if ($settings.Version -notmatch '^\d+\.\d+\.\d+$' -or $settings.SHA256 -notmatch '^[0-9A-Fa-f]{64}$') { throw 'Invalid update manifest.' }
        $expectedUrl = 'https://raw.githubusercontent.com/ILoveYouBev/workplaceUI/main/releases/CSRTools-' + $settings.Version + '.zip'
        if ($settings.Package -ne $expectedUrl) { throw 'The update package URL is not trusted.' }
        $stageRoot = Join-Path $env:TEMP ('CSRTools-update-' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $stageRoot | Out-Null
        $zip = Join-Path $stageRoot 'update.zip'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        if ($Mode -eq 'Verify') { Copy-Item -LiteralPath $PackagePath -Destination $zip }
        else { Invoke-WebRequest -Uri $settings.Package -OutFile $zip -UseBasicParsing -TimeoutSec 90 }
        if ((Get-CSRFileSHA256 -LiteralPath $zip) -ne $settings.SHA256) { throw 'Update checksum mismatch. No installed files were changed.' }
        Initialize-CSRZipRuntime
        $archive = [IO.Compression.ZipFile]::OpenRead($zip)
        try {
            $seen = @{}
            $totalBytes = 0L
            if ($archive.Entries.Count -gt 2048) { throw 'Too many package entries.' }
            foreach ($entry in $archive.Entries) {
                $relative = $entry.FullName.Replace('/','\')
                Resolve-SafeChild $stageRoot $relative | Out-Null
                if ($seen.ContainsKey($relative)) { throw 'Duplicate package path.' }
                $seen[$relative] = $true
                $totalBytes += $entry.Length
                if ($entry.Length -gt 52428800 -or $totalBytes -gt 134217728) { throw 'Oversized update package.' }
            }
        } finally { $archive.Dispose() }
        $unpacked = Join-Path $stageRoot 'package'
        [IO.Compression.ZipFile]::ExtractToDirectory($zip, $unpacked)
        $package = [IO.File]::ReadAllText((Join-Path $unpacked 'package-manifest.json')) | ConvertFrom-Json
        if ($package.version -ne $settings.Version) { throw 'Package version does not match the update manifest.' }
        $listed = @{}
        foreach ($file in $package.files) {
            $relative = [string]$file.path
            if ($relative -notin $requiredFiles -and $relative -notmatch '^Image Search/[^/\\]+\.png$|^Hotstrings/[^/\\]+\.txt$') { throw 'Unexpected package content.' }
            if ($listed.ContainsKey($relative)) { throw 'Duplicate file manifest entry.' }
            $listed[$relative] = $true
            $source = Resolve-SafeChild $unpacked $relative
            if ((Get-CSRFileSHA256 -LiteralPath $source) -ne $file.sha256) { throw "Package file checksum mismatch: $relative" }
        }
        foreach ($relative in $requiredFiles) { if (!$listed.ContainsKey($relative)) { throw "Incomplete update: $relative" } }
        $exeInfo = [Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $unpacked 'CSR Tools.exe'))
        if ($exeInfo.ProductVersion -ne $settings.Version) { throw 'EXE version mismatch.' }
        if ($Mode -eq 'Verify') { Write-Result 'VERIFIED' 'Package checksum, safe paths, contents and EXE version verified.'; exit 0 }
        if ($WaitPid -gt 0 -and (Get-Process -Id $WaitPid -ErrorAction SilentlyContinue)) { Wait-Process -Id $WaitPid -Timeout 60 -ErrorAction Stop }
        $lockPath = Join-Path $script:workspaceRoot '.csr-update.lock'
        $updateLock = [IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        $backupRoot = Join-Path $script:workspaceRoot ('_UpdateBackups\' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N'))
        $changed = [Collections.Generic.List[string]]::new()
        try {
            foreach ($file in $package.files) {
                $relative = [string]$file.path
                $dest = Resolve-SafeChild $script:workspaceRoot $relative
                if ($relative -like 'Hotstrings/*' -and (Test-Path -LiteralPath $dest)) { continue }
                if (Test-Path -LiteralPath $dest) {
                    $backup = Resolve-SafeChild $backupRoot $relative
                    New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($backup)) -Force | Out-Null
                    Copy-Item -LiteralPath $dest -Destination $backup
                }
                $changed.Add($relative)
                New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($dest)) -Force | Out-Null
                Copy-Item -LiteralPath (Resolve-SafeChild $unpacked $relative) -Destination $dest -Force
            }
            $oldHotstring = Join-Path $script:workspaceRoot 'Hotstrings\-checknis.txt'
            if ((Test-Path -LiteralPath $oldHotstring) -and [IO.File]::ReadAllText($oldHotstring).Trim() -eq '=IFERROR(IF((D3-E3)=0,"",D3-E3),D3)') {
                New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
                Move-Item -LiteralPath $oldHotstring -Destination (Join-Path $backupRoot '-checknis.txt')
            }
        } catch {
            foreach ($relative in $changed) {
                $dest = Resolve-SafeChild $script:workspaceRoot $relative
                $backup = Resolve-SafeChild $backupRoot $relative
                if (Test-Path -LiteralPath $backup) { Copy-Item -LiteralPath $backup -Destination $dest -Force }
                elseif (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest }
            }
            throw
        } finally { $updateLock.Dispose() }
        Start-Process -FilePath (Join-Path $script:workspaceRoot 'CSR Tools.exe') -WindowStyle Hidden
        Write-Result 'INSTALLED' ('Installed ' + $settings.Version)
    } else { throw 'Choose a supported mode.' }
} catch {
    Write-Result 'FAILED' $_.Exception.Message
    if ($Mode -eq 'Install') {
        Add-Type -AssemblyName System.Windows.Forms
        [Windows.Forms.MessageBox]::Show(('The update could not be completed. ' + $_.Exception.Message + "`n`nYour account file and preferences were preserved. Result: " + $ResultPath),'CSR Tools update failed') | Out-Null
        $existingExe = Join-Path $script:workspaceRoot 'CSR Tools.exe'
        if (Test-Path -LiteralPath $existingExe) { Start-Process -FilePath $existingExe -WindowStyle Hidden }
        elseif ($AutoHotkeyPath -and (Test-Path -LiteralPath $AutoHotkeyPath)) { Start-Process -FilePath $AutoHotkeyPath -ArgumentList ('/restart "' + (Join-Path $script:workspaceRoot 'CSR TOOL 4.3.AHK') + '"') -WindowStyle Hidden }
    }
    if (!$ResultPath) { Write-Error $_ }
    exit 1
}
